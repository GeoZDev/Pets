<?php

namespace pets;

class ElderGuardianPet extends Pets {

	const NETWORK_ID = 50;

	public $width = 1.0;
	public $length = 1.0;
	public $height = 1.0;

	public function getName() {
		return "ElderGuardianPet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
