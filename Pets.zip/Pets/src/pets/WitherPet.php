<?php

namespace pets;

class WitherPet extends Pets {

	const NETWORK_ID = 52;

	public $width = 0.98;
	public $length = 0.98;
	public $height = 0.98;

	public function getName() {
		return "WitherPet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
