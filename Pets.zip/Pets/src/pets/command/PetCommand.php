<?php

namespace pets\command;

use pocketmine\command\CommandSender;
use pocketmine\command\PluginCommand;
use pets\main;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class PetCommand extends PluginCommand {

	public function __construct(main $main, $name) {
		parent::__construct(
				$name, $main
		);
		$this->main = $main;
		$this->setPermission("pets.command");
		$this->setAliases(array("pets"));
	}

	public function execute(CommandSender $sender, $currentAlias, array $args) {
	if($sender->hasPermission('pets.command')){
		if (!isset($args[0])) {
			$sender->sendMessage("§e======Pet, tradotto da GeoZDev======");
			$sender->sendMessage("§a/pets type [Nomepet]");
			$sender->sendMessage("§eLista pets: dog, rabbit, pig, cat, chicken, zombie, snowgolem, spider, irongolem, bat, dragon, polarbear, enderman, squid, mooshroom, guardian, elderguardian, wither, shulker, horse");
			$sender->sendMessage("§b/pets off per levare il tuo pet");
			
			return true;
		}
		switch (strtolower($args[0])){
			case "name":
			case "setname":
				if (isset($args[1])){
					unset($args[0]);
					$name = implode(" ", $args);
					$this->main->getPet($sender->getName())->setNameTag($name);
					$sender->sendMessage("Set Name to ".$name);
					$data = new Config($this->main->getDataFolder() . "players/" . strtolower($sender->getName()) . ".yml", Config::YAML);
					$data->set("name", $name); 
					$data->save();
				}
				return true;
		}
		switch (strtolower($args[0])){
			case "name":
				if (isset($args[1])){
					unset($args[0]);
					$name = implode(" ", $args);
					$this->main->getPet($sender->getName())->setNameTag($name);
					$sender->sendMessage("Set Name to ".$name);
				}
				return true;			
			break;
			case "help":
				$sender->sendMessage("§e======Pet tradotto da GeoZDev======");
				$sender->sendMessage("§a/pets type [Nomepet]");
				$sender->sendMessage("§eLista pets: dog, rabbit, pig, cat, chicken, zombie, snowgolem, spider, irongolem, bat, dragon, polarbear, enderman, squid, mooshroom, guardian, elderguardian, wither, shulker, horse");
				$sender->sendMessage("§b/pets off per levare il pet");
				return true;
			break;
			case "off":
				$this->main->disablePet($sender);
			break;
			case "type":
				if (isset($args[1])){
					switch ($args[1]){
						case "wolf":
						case "dog":
							$this->main->changePet($sender, "WolfPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un Lupo!");
							return true;
						break;
						case "pig":
							$this->main->changePet($sender, "PigPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un maiale!");
							return true;
						break;
						case "rabbit":
							$this->main->changePet($sender, "RabbitPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un coniglio!");
							return true;
						break;
						case "cat":
							$this->main->changePet($sender, "OcelotPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un gattopardo!");
							return true;
						break;
						case "chicken":
							$this->main->changePet($sender, "ChickenPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in una gallina!");
							return true;
						break;
						case "zombie":
							$this->main->changePet($sender, "(ZombiePet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in uno zombie!");
							return true;
						break;
						case "spider":
							$this->main->changePet($sender, "SpiderPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un ragno!");
							return true;
						break;
						case "snowgolem":
							$this->main->changePet($sender, "SnowGolemPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un SnowGolem!");
							return true;
						break;
						case "irongolem":
							$this->main->changePet($sender, "IronGolemPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un IronGolem!");
							return true;
						break;
						case "bat":
							$this->main->changePet($sender, "BatPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un pipistrello!");
							return true;
						break;
						case "enderman":
							$this->main->changePet($sender, "EndermanPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un Enderman!");
							return true;
						break;
						case "polarbear":
							$this->main->changePet($sender, "PolarBearPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un orso polare!");
							return true;
						break;
						case "guardian":
							$this->main->changePet($sender, "GuardianPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un guardiano!");
							return true;
						break;
						case "endercrystal":
							$this->main->changePet($sender, "EnderCrystalPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un Ender Crystal!");
							return true;
						break;
						case "mooshroom":
							$this->main->changePet($sender, "MooshroomPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un Mooshroom!");
							return true;
						break;
						case "horse":
							$this->main->changePet($sender, "HorsePet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un cavallo!");
							return true;
						break;
						case "elderguardian":
							$this->main->changePet($sender, "ElderGuardianPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un Elder Guardian!");
							return true;
						break;
						case "squid":
							$this->main->changePet($sender, "SquidPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in uno Squid!");
							return true;
						break;
						case "wither":
							$this->main->changePet($sender, "WitherPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un Wither!");
							return true;
						break;
						case "dragon":
							$this->main->changePet($sender, "DragonPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in un Drago!");
							return true;
						break;						
						case "shulker":
							$this->main->changePet($sender, "ShulkerPet");
							$sender->sendMessage("§aIl tuo pet è stato cambiato in uno Shulker");
							return true;
						break;
					default:
						$sender->sendMessage("§a/pets type [Nomepet]");
						$sender->sendMessage("§bLista pet: dog, rabbit, pig, cat, chicken, zombie, snowgolem, spider, irongolem, bat, dragon, polarbear, enderman, squid, mooshroom, guardian, elderguardian, wither, shulker, horse");
					break;	
					return true;
					}
				}
			break;
		}
		return true;
	}
	}
}
