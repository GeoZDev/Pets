<?php

namespace pets;

class MooshroomPet extends Pets {

	const NETWORK_ID = 16;

	public $width = 0.3;
	public $length = 0.9;
	public $height = 1.8;

	public function getName() {
		return "MooshroomPet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
