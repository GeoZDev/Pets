<?php

namespace pets;

class DragonPet extends Pets {

	const NETWORK_ID = 53;

	public $width = 1.0;
	public $length = 5.0;
	public $height = 2.0;

	public function getName() {
		return "DragonPet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
