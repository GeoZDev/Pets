<?php

namespace pets;

class SquidPet extends Pets {

	const NETWORK_ID = 17;

	public $width = 0.95;
	public $length = 0.95;
	public $height = 0.95;

	public function getName() {
		return "SquidPet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
