<?php

namespace pets;

class PolarBearPet extends Pets {

	const NETWORK_ID = 28;

	public $width = 0.2;
	public $length = 0.1;
	public $height = 0.5;

	public function getName() {
		return "PolarBearPet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
