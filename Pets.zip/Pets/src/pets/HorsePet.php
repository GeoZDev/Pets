<?php

namespace pets;

class HorsePet extends Pets {

	const NETWORK_ID = 23;

	public $width = 0.6;
	public $length = 0.6;
	public $height = 1.8;

	public function getName() {
		return "HorsePet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
