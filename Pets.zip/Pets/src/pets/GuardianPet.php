<?php

namespace pets;

class GuardianPet extends Pets {

	const NETWORK_ID = 49;

	public $width = 1.0;
	public $length = 1.0;
	public $height = 1.0;

	public function getName() {
		return "GuardianPet";
	}

	public function getSpeed() {
		return 2.0;
	}

}
